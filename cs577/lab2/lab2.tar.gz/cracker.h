#ifndef _CRACKER_H_
#define _CRACKER_H_

#include <stdlib.h>
#include <time.h>
#include <string>
#include <openssl/md5.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <functional>
#endif
