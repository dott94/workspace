#ifndef _SOCKETS_H_
#define _SOCKETS_H_
#define BUFFER_SIZE 512
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <resolv.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <netdb.h>
int sockfd;

#endif
